#!/system/bin/sh
C=/data/adb/.config/encore_pixel_cp41
M=/data/adb/modules/encore_pixel_cp41
date
cat /proc/uptime
for f in controller.pid brain.pid; do
 p=$(cat "$C/$f" 2>/dev/null)
 echo "=== $f $p ==="
 readlink /proc/$p/exe
 sed -n '1,34p' /proc/$p/status
 printf 'wchan='; cat /proc/$p/wchan
 printf 'schedstat='; cat /proc/$p/schedstat
 for t in /proc/$p/task/*; do
  id=${t##*/}; printf 'thread=%s ' "$id"; cat "$t/comm" "$t/wchan" 2>/dev/null | tr '\n' ' '; echo
 done
 echo 'kernel stack'; cat /proc/$p/stack 2>/dev/null | head -n 12
done
for f in status scene request heartbeat frame-policy-journal; do echo "=== $f ==="; cat "$C/$f" 2>/dev/null; done
ps -A -o PID,PPID,STAT,ARGS | grep -E 'pixel-control|encored|service.sh|dumpsys|timeout|sh -c' | grep -v grep
printf 'battery='; cat /sys/class/power_supply/battery/capacity
printf 'boot='; cat /proc/sys/kernel/random/boot_id
printf 'fps='; getprop debug.graphics.game_default_frame_rate.disabled
