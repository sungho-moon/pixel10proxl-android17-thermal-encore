#!/system/bin/sh
set -eu
M=/data/adb/modules/encore_pixel_cp41
T=$(mktemp /data/local/tmp/encore-ui-schema.XXXXXX)
trap 'rm -f "$T"' EXIT
printf '%s' 'ew==' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_config "$T"
R=$?
set -e
[ "$R" = 1 ] || exit 1
echo invalid-syntax_PASS
printf '%s' 'e30=' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_config "$T"
R=$?
set -e
[ "$R" = 1 ] || exit 1
echo missing-preferences_PASS
printf '%s' 'eyJwcmVmZXJlbmNlcyI6eyJlbmZvcmNlX2xpdGVfbW9kZSI6ZmFsc2UsImRpc2FibGVfdHdlYWtzIjpmYWxzZSwibG9nX2xldmVsIjo5OX19' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_config "$T"
R=$?
set -e
[ "$R" = 1 ] || exit 1
echo invalid-log-level_PASS
printf '%s' 'eyJjb20udGVuY2VudC50bWdwLmRmbSI6eyJsaXRlX21vZGUiOiJ0cnVlIn19' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_gamelist "$T"
R=$?
set -e
[ "$R" = 1 ] || exit 1
echo invalid-game-type_PASS
printf '%s' 'eyJiYWQ7bmFtZSI6eyJsaXRlX21vZGUiOmZhbHNlfX0=' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_gamelist "$T"
R=$?
set -e
[ "$R" = 1 ] || exit 1
echo invalid-package_PASS
printf '%s' 'e30=' | base64 -d > "$T"
set +e
"$M/bin/encored" validate_gamelist "$T"
R=$?
set -e
[ "$R" = 0 ] || exit 1
echo empty-game-list_PASS
