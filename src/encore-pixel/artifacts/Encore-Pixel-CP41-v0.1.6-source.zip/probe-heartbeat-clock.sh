#!/system/bin/sh
C=/data/adb/.config/encore_pixel_cp41
printf 'epoch='; date +%s
printf 'heartbeat_mtime='; stat -c %Y "$C/heartbeat"
printf 'heartbeat='; cat "$C/heartbeat"
printf 'uptime='; cat /proc/uptime
