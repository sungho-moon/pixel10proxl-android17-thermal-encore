#!/system/bin/sh
set -eu
M=/data/adb/modules/encore_pixel_cp41
C=/data/adb/.config/encore_pixel_cp41
T=/data/local/tmp/encore-pixel-v014-final
B="$C/webui-v014-strict-backup"
[ "$(getprop ro.build.id)" = CP41.260831.007 ] || exit 1
grep -q '^id=encore_pixel_cp41$' "$M/module.prop"
[ ! -f "$M/disable" ] && [ ! -f "$M/update" ] && [ ! -f "$M/remove" ]
WAS_PAUSED=0
[ ! -f "$C/pause" ] || WAS_PAUSED=1
[ ! -e "$B" ] || exit 1
(cd "$T" && sha256sum -c INSTALL_SHA256SUMS)
(cd "$M" && sha256sum -c SHA256SUMS)
mkdir -p "$B/bin"
for f in bin/encored bin/pixel-control PROVENANCE.json module.prop SHA256SUMS INSTALL_SHA256SUMS; do cp "$M/$f" "$B/$f"; done
touch "$C/pause"
PID=$(cat "$C/controller.pid" 2>/dev/null || true)
PARENT=0
if [ -n "$PID" ] && [ -r /proc/$PID/status ]; then PARENT=$(awk '/^PPid:/ {print $2}' /proc/$PID/status); fi
if [ -n "$PID" ] && [ "$(readlink /proc/$PID/exe)" = "$M/bin/pixel-control" ]; then kill -TERM "$PID"; fi
for i in $(seq 1 15); do [ ! -f "$C/controller.pid" ] && break; sleep 1; done
[ ! -f "$C/controller.pid" ] || exit 1
if [ "$PARENT" -gt 1 ] && [ -r /proc/$PARENT/cmdline ] && tr '\000' ' ' < /proc/$PARENT/cmdline | grep -F "$M/service.sh" >/dev/null; then
 for i in $(seq 1 15); do kill -0 "$PARENT" 2>/dev/null || break; sleep 1; done
 kill -0 "$PARENT" 2>/dev/null && exit 1
fi
"$M/bin/pixel-control" restore
mv "$M/webroot" "$B/webroot"
cp -R "$T/webroot" "$M/webroot"
for f in bin/encored bin/pixel-control PROVENANCE.json module.prop SHA256SUMS INSTALL_SHA256SUMS ui-state.sh ui-write.sh; do
 cp "$T/$f" "$M/$f.new"
 case "$f" in bin/*|*.sh) chmod 755 "$M/$f.new";; *) chmod 644 "$M/$f.new";; esac
 mv "$M/$f.new" "$M/$f"
done
(cd "$M" && sha256sum -c SHA256SUMS)
if [ "$WAS_PAUSED" = 0 ] || [ "${1:-}" = resume ]; then
 rm -f "$C/pause"
 nohup sh "$M/service.sh" >> "$C/bootstrap.log" 2>&1 </dev/null &
 echo "WEBUI_UPGRADE_APPLIED service_pid=$! backup=$B"
else
 echo "WEBUI_UPGRADE_APPLIED kept_paused=1 backup=$B"
fi
