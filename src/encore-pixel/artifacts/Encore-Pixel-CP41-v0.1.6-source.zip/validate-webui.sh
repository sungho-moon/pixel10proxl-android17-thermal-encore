#!/system/bin/sh
set -eu
M=/data/adb/modules/encore_pixel_cp41
C=/data/adb/.config/encore_pixel_cp41
sh "$M/ui-state.sh" | grep -q '^process_ok=1$'
LOG_START=$(wc -l < "$C/encore.log")
ORIGINAL='ewogICJwcmVmZXJlbmNlcyI6IHsKICAgICJlbmZvcmNlX2xpdGVfbW9kZSI6IGZhbHNlLAogICAgInVzZV9kZXZpY2VfbWl0aWdhdGlvbiI6IGZhbHNlLAogICAgImRpc2FibGVfdHdlYWtzIjogZmFsc2UsCiAgICAibG9nX2xldmVsIjogMwogIH0sCiAgImNwdV9nb3Zlcm5vciI6IHsKICAgICJiYWxhbmNlIjogInNjaGVkX3BpeGVsIiwKICAgICJwb3dlcnNhdmUiOiAic2NoZWRfcGl4ZWwiCiAgfQp9Cg=='
DEBUG='ewogICJwcmVmZXJlbmNlcyI6IHsKICAgICJlbmZvcmNlX2xpdGVfbW9kZSI6IGZhbHNlLAogICAgInVzZV9kZXZpY2VfbWl0aWdhdGlvbiI6IGZhbHNlLAogICAgImRpc2FibGVfdHdlYWtzIjogZmFsc2UsCiAgICAibG9nX2xldmVsIjogNAogIH0sCiAgImNwdV9nb3Zlcm5vciI6IHsKICAgICJiYWxhbmNlIjogInNjaGVkX3BpeGVsIiwKICAgICJwb3dlcnNhdmUiOiAic2NoZWRfcGl4ZWwiCiAgfQp9Cg=='
GAMES='ewogICJjb20ubmV0ZWFzZS5za3kiOiB7CiAgICAibGl0ZV9tb2RlIjogZmFsc2UsCiAgICAiZW5hYmxlX2RuZCI6IGZhbHNlCiAgfSwKICAiY29tLnRlbmNlbnQudG1ncC5wdWJnbWhkIjogewogICAgImxpdGVfbW9kZSI6IGZhbHNlLAogICAgImVuYWJsZV9kbmQiOiBmYWxzZQogIH0sCiAgImNvbS50ZW5jZW50LnRtZ3AuZGZtIjogewogICAgImxpdGVfbW9kZSI6IGZhbHNlLAogICAgImVuYWJsZV9kbmQiOiBmYWxzZQogIH0KfQ=='
OLD_HASH=$(sha256sum "$C/config.json"); OLD_GAME_HASH=$(sha256sum "$C/gamelist.json")
CHANGED=0
cleanup() {
 if [ "$CHANGED" = 1 ]; then
  sh "$M/ui-write.sh" config "$ORIGINAL" "$DEBUG" || echo 'ERROR: automatic config restoration rejected; inspect current config'
 fi
}
trap cleanup EXIT
trap 'exit 130' INT TERM HUP
# Validate before replacing and reject stale content.
set +e
sh "$M/ui-write.sh" config 'ew==' "$ORIGINAL"
R=$?
set -e
[ "$R" = 5 ] || { echo "INVALID_REJECTION_FAIL=$R"; exit 1; }
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
echo INVALID_JSON_REJECTION_PASS
set +e
sh "$M/ui-write.sh" config "$ORIGINAL" 'e30='
R=$?
set -e
[ "$R" = 4 ] || { echo "STALE_REJECTION_FAIL=$R"; exit 1; }
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
echo STALE_WRITE_REJECTION_PASS
CHANGED=1
sh "$M/ui-write.sh" config "$DEBUG" "$ORIGINAL"
sleep 2
sh "$M/ui-write.sh" games "$GAMES" "$GAMES"
sleep 2
sed -n "$((LOG_START+1)),\$p" "$C/encore.log"
sh "$M/ui-write.sh" config "$ORIGINAL" "$DEBUG"
CHANGED=0
sleep 2
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
[ "$(sha256sum "$C/gamelist.json")" = "$OLD_GAME_HASH" ]
[ ! -d "$C/ui-write-lock" ]
echo CONFIG_AND_GAMES_EXACT_HASH_RESTORED_PASS
sh "$M/ui-state.sh"
sh "$M/ui-state.sh" | grep -q '^process_ok=1$'
echo WEBUI_BACKEND_VALIDATION_PASS
