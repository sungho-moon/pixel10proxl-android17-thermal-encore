#!/system/bin/sh
set -eu
M=/data/adb/modules/encore_pixel_cp41
C=/data/adb/.config/encore_pixel_cp41
T=/data/local/tmp/encore-pixel-v015
B="$C/status-hotfix-v015-backup"
[ "$(getprop ro.product.device)" = mustang ]
[ "$(getprop ro.build.id)" = CP41.260831.007 ]
grep -q '^versionCode=104$' "$M/module.prop"
[ ! -e "$B" ]
(cd "$M" && sha256sum -c SHA256SUMS) > "$C/status-hotfix-current-check.log"
(cd "$T" && sha256sum -c INSTALL_SHA256SUMS) > "$C/status-hotfix-staged-check.log"
CURRENT=$(sed '/  ui-state.sh$/d' "$M/SHA256SUMS")
TARGET=$(sed '/  ui-state.sh$/d' "$T/SHA256SUMS")
[ "$CURRENT" = "$TARGET" ] || { echo 'Unexpected runtime change in staged module'; exit 1; }
mkdir "$B"
for f in ui-state.sh SHA256SUMS INSTALL_SHA256SUMS module.prop; do cp "$M/$f" "$B/$f"; done
COMMITTED=0
rollback() {
 if [ "$COMMITTED" != 1 ]; then
  for f in ui-state.sh SHA256SUMS INSTALL_SHA256SUMS module.prop; do cp "$B/$f" "$M/$f"; done
  chmod 755 "$M/ui-state.sh"
  echo 'Status hotfix rolled back' >&2
 fi
}
trap rollback EXIT
for f in ui-state.sh SHA256SUMS INSTALL_SHA256SUMS module.prop; do
 cp "$T/$f" "$M/$f.new"
 case "$f" in *.sh) chmod 755 "$M/$f.new";; *) chmod 644 "$M/$f.new";; esac
 mv "$M/$f.new" "$M/$f"
done
(cd "$M" && sha256sum -c SHA256SUMS) > "$C/status-hotfix-new-check.log"
sh "$M/ui-state.sh" | grep -q '^process_ok=1$'
COMMITTED=1
trap - EXIT
echo STATUS_HOTFIX_APPLIED
sh "$M/ui-state.sh"
