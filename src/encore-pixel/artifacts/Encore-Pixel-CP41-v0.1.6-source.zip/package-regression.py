from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent
with zipfile.ZipFile(root / 'artifacts/Encore-Pixel-CP41-v0.1.6-test.zip') as z:
    extracted = {n: z.read(n) for n in z.namelist() if not n.startswith('META-INF/')}
    installed = {n: v for n, v in extracted.items() if n not in ['customize.sh', 'README.md']}
    def check(data, name):
        errors = []
        for row in extracted[name].decode().splitlines():
            expected, item = row.split('  ', 1)
            if item not in data or hashlib.sha256(data[item]).hexdigest() != expected:
                errors.append(item)
        return errors
    assert check(extracted, 'INSTALL_SHA256SUMS') == []
    assert check(installed, 'SHA256SUMS') == []
    for critical in ['bin/pixel-control', 'bin/encored', 'service.sh', 'binder_resolver.apk']:
        changed = dict(installed)
        changed[critical] += b'changed'
        assert check(changed, 'SHA256SUMS') == [critical]
    assert b'versionCode=106' in extracted['module.prop']
    assert b'INSTALL_SHA256SUMS' in extracted['customize.sh']
    assert b'sha256sum -c SHA256SUMS' in extracted['service.sh']
    for critical in ['webroot/index.html','ui-state.sh','ui-write.sh']:
        assert critical in installed
    print(f"0.1.6 installation manifest: {len(extracted['INSTALL_SHA256SUMS'].splitlines())} checksums PASS")
    print(f"0.1.6 post-KernelSU-cleanup runtime manifest: {len(extracted['SHA256SUMS'].splitlines())} checksums PASS")
    print('Native executable / service / resolver corruption rejection: PASS')
