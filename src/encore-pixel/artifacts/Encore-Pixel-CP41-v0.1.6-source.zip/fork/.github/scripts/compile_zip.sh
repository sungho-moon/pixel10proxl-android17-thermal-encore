#!/bin/env bash
# shellcheck disable=SC2035

if [ -z "$GITHUB_WORKSPACE" ]; then
	echo "This script should only run on GitHub action!" >&2
	exit 1
fi

# Make sure we're on right directory
cd "$GITHUB_WORKSPACE" || {
	echo "Unable to cd to GITHUB_WORKSPACE" >&2
	exit 1
}

# Version info
version="$(cat version)"
version_code="$(git rev-list HEAD --count)"
branch_name="$(git rev-parse --abbrev-ref HEAD)"
release_code="$(git rev-list HEAD --count)-$(git rev-parse --short HEAD)-${branch_name//_/-}"
sed -i "s/version=.*/version=$version ($release_code)/" module/module.prop
sed -i "s/versionCode=.*/versionCode=$version_code/" module/module.prop

# Copy module files
cp -r ./libs module
cp -r ./scripts/* module/system/bin
cp gamelist.txt module
cp LICENSE module
cp NOTICE.md module

find ./prebuilt -mindepth 1 -maxdepth 1 ! -name "README.md" -exec cp -r {} ./module \;
find ./config -mindepth 1 -maxdepth 1 ! -name "README.md" -exec cp -r {} ./module/config \;

# Download banner image
wget -O module/banner.webp https://encore.rem01gaming.dev/ogp/default.webp

# Remove .sh extension from scripts
find module/system/bin -maxdepth 1 -type f -name "*.sh" -exec sh -c 'mv -- "$0" "${0%.sh}"' {} \;

# Parse version info to module prop
zipName="encore-$version-$release_code.zip"
echo "zipName=$zipName" >>"$GITHUB_OUTPUT"

# Generate sha256sum for integrity checkup
bash .github/scripts/gen_sha256sum.sh "module"

cd ./module || {
	echo "Unable to cd to ./module" >&2
	exit 1
}

# Zip the file
zip -r9 ../"$zipName" * -x *placeholder* *.map .shellcheckrc
zip -z ../"$zipName" <<EOF
$version-$release_code
Build Date $(date +"%a %b %d %H:%M:%S %Z %Y")
EOF
