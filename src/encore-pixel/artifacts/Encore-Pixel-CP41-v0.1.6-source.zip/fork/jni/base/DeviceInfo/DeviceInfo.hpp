/*
 * Copyright (C) 2026 Rem01Gaming
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once
#include <string>

class DeviceInfo {
public:
    static const std::string& get_kernel_uname();
    static const std::string& get_soc_model();
    static const std::string& get_device_model();

private:
    static std::string fetch_kernel_uname();
    static std::string fetch_soc_model();
    static std::string fetch_device_model();
};
