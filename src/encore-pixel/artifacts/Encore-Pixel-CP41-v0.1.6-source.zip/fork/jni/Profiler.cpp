// Modified for Encore Pixel CP41 (2026): native Pixel control, lifecycle and Android 17 compatibility.
/*
 * Copyright (C) 2024-2026 Rem01Gaming
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Pixel CP41 fork: replace upstream hardware shell commands with an atomic request.
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include "Encore.hpp"
#include "EncoreLog.hpp"
#include "Profiler.hpp"
#include "EncoreConfigStore.hpp"
#include "Write2File.hpp"

static void request(int mode, bool lite, const std::string& pkg, pid_t pid, uid_t uid) {
    if (config_store.get_preferences().disable_tweaks) { mode = BALANCE_PROFILE; pid = 0; }
    write2file(GAME_INFO, pkg, " ", pid, " ", uid, "\n");
    write2file(PROFILE_MODE, mode, "\n");
    const char* tmp = CONFIG_DIR "/request.tmp";
    FILE* f = fopen(tmp, "w");
    if (!f) { LOGE("Cannot open Pixel request"); return; }
    fprintf(f, "%d %d %s %d %u\n", mode, lite, pkg.c_str(), pid, uid);
    bool ok = fflush(f) == 0 && fsync(fileno(f)) == 0;
    fclose(f);
    if (!ok || rename(tmp, CONFIG_DIR "/request") != 0) LOGE("Cannot publish Pixel request");
}
void set_profiler_env_vars() {}
void run_perfcommon() { request(PERFCOMMON, false, "NULL", 0, 0); }
void apply_performance_profile(bool lite, std::string pkg, pid_t pid, uid_t uid) { request(PERFORMANCE_PROFILE, lite, pkg, pid, uid); }
void apply_balance_profile() { request(BALANCE_PROFILE, false, "NULL", 0, 0); }
void apply_powersave_profile() { request(POWERSAVE_PROFILE, false, "NULL", 0, 0); }
