---
title: Frequently Asked Questions
description: Answers to frequently asked questions about Encore Tweaks, covering device compatibility, configuration, activation, and troubleshooting.
---

# Frequently Asked Questions 

Find answers to common questions about using Encore Tweaks, including setup, supported devices, troubleshooting, and more.

---

## Does Encore Tweaks support my device?
Encore Tweaks is compatible with a wide range of devices, including those using Mediatek, Snapdragon, Google Tensor, Exynos, Tegra, and Unisoc chipsets. Even if your device doesn't use one of these chipsets, you may still be able to use Encore Tweaks.

---

## How do I activate Encore Tweaks?
Encore Tweaks automatically runs on boot, so you don't need to start it manually.

---

## Where I can download the Encore Tweaks app?
Encore Tweaks never had an App for UI configuration, you maybe meant the [Module WebUI](/guide/getting-started#configuration).

---

## Does Encore Tweaks require a BusyBox module?
No, Encore Tweaks does not require a BusyBox module.

---

## Can I use Encore Tweaks with other performance modules?
We do not recommend using Encore Tweaks alongside other performance modules, as they are likely to conflict. This includes modules like YAKT, Magnetar, Uperf and fas-rs. However, Thermal Killer and Thermal mod modules can be safely used alongside Encore Tweaks.

---

## How I can change the performance profile manually?
Encore Tweaks doesn't have manual profile selection. however Encore Tweaks service will change performance profile automatically for you so you don't have to tune anything.

---

## Do Encore Tweaks impact battery life?
While playing game Encore Tweaks will comsume more power, but on normal usage this module will not consume more power. you can also cut your power consumption by using powersave profile by Encore Tweaks with enabling battery saver mode on quick settings.

---

## Is Encore Tweaks a scheduler module similar to Uperf?
No, Encore Tweaks works in more traditional way compared to Uperf, it's never meant to be a scheduler such as Uperf and Tritium nor integrated with Scene and other managers.

---

## Why Encore Tweaks WebUI only showing white page?
Your ROM WebView version is too old, to fix this [update your WebView](https://play.google.com/store/apps/details?id=com.google.android.webview) to the latest version.

---

## Why I can't enable powersave profile on HyperOS/MIUI?
Due to bug or intended behavior on these ROMs by Xiaomi Engineers, battery saver detection does not work, and we're unable to make it to work on these ROMs. Consider moving to AOSP ROM.

---

## How can I access WebUI?
- **KernelSU or APatch Users**: Click "open" in the module card to access the WebUI.
- **Magisk Users**: Native WebUI support isn't available in Magisk. Use [WebUI X](https://github.com/MMRLApp/WebUI-X-Portable) to access the WebUI if needed.

---

## What should I do if I find a bug or issue in Encore Tweaks?
Report any issues or bugs [here](https://github.com/Rem01Gaming/encore/issues).
