from pathlib import Path
import subprocess, json, base64
root = Path.cwd()
adb = root/'outputs/adb-temp.exe'
b = root/'work/encore-pixel'
def read(name):
    p=subprocess.run([str(adb),'exec-out','su','-c',f'cat /data/adb/.config/encore_pixel_cp41/{name}'],capture_output=True,check=True)
    return p.stdout.decode().replace('\r\n','\n')
original=read('config.json'); games=read('gamelist.json')
config=json.loads(original); config['preferences']['log_level']=4
changed=json.dumps(config,indent=2)+'\n'
def enc(s):return base64.b64encode(s.encode()).decode()
script='''#!/system/bin/sh
set -eu
M=/data/adb/modules/encore_pixel_cp41
C=/data/adb/.config/encore_pixel_cp41
sh "$M/ui-state.sh" | grep -q '^process_ok=1$'
LOG_START=$(wc -l < "$C/encore.log")
ORIGINAL='@ORIGINAL@'
DEBUG='@DEBUG@'
GAMES='@GAMES@'
OLD_HASH=$(sha256sum "$C/config.json"); OLD_GAME_HASH=$(sha256sum "$C/gamelist.json")
CHANGED=0
cleanup() {
 if [ "$CHANGED" = 1 ]; then
  sh "$M/ui-write.sh" config "$ORIGINAL" "$DEBUG" || echo 'ERROR: automatic config restoration rejected; inspect current config'
 fi
}
trap cleanup EXIT
trap 'exit 130' INT TERM HUP
# Validate before replacing and reject stale content.
set +e
sh "$M/ui-write.sh" config 'ew==' "$ORIGINAL"
R=$?
set -e
[ "$R" = 5 ] || { echo "INVALID_REJECTION_FAIL=$R"; exit 1; }
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
echo INVALID_JSON_REJECTION_PASS
set +e
sh "$M/ui-write.sh" config "$ORIGINAL" 'e30='
R=$?
set -e
[ "$R" = 4 ] || { echo "STALE_REJECTION_FAIL=$R"; exit 1; }
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
echo STALE_WRITE_REJECTION_PASS
CHANGED=1
sh "$M/ui-write.sh" config "$DEBUG" "$ORIGINAL"
sleep 2
sh "$M/ui-write.sh" games "$GAMES" "$GAMES"
sleep 2
sed -n "$((LOG_START+1)),\\$p" "$C/encore.log"
sh "$M/ui-write.sh" config "$ORIGINAL" "$DEBUG"
CHANGED=0
sleep 2
[ "$(sha256sum "$C/config.json")" = "$OLD_HASH" ]
[ "$(sha256sum "$C/gamelist.json")" = "$OLD_GAME_HASH" ]
[ ! -d "$C/ui-write-lock" ]
echo CONFIG_AND_GAMES_EXACT_HASH_RESTORED_PASS
sh "$M/ui-state.sh"
sh "$M/ui-state.sh" | grep -q '^process_ok=1$'
echo WEBUI_BACKEND_VALIDATION_PASS
'''
for k,v in [('ORIGINAL',enc(original)),('DEBUG',enc(changed)),('GAMES',enc(games))]:script=script.replace('@'+k+'@',v)
(b/'validate-webui.sh').write_text(script,encoding='utf-8',newline='\n')
print('validation script created')
