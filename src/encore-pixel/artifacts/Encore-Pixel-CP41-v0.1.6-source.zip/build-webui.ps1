$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot 'fork/webui')
try {
    & npm.cmd ci --ignore-scripts --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw 'WebUI dependency installation failed' }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'WebUI build failed' }
} finally { Pop-Location }
