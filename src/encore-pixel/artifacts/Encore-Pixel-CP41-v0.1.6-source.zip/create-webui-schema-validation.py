from pathlib import Path
import subprocess,base64
r=Path.cwd(); b=r/'work/encore-pixel'
cases=[('invalid-syntax','validate_config','{'),('missing-preferences','validate_config','{}'),('invalid-log-level','validate_config','{"preferences":{"enforce_lite_mode":false,"disable_tweaks":false,"log_level":99}}'),('invalid-game-type','validate_gamelist','{"com.tencent.tmgp.dfm":{"lite_mode":"true"}}'),('invalid-package','validate_gamelist','{"bad;name":{"lite_mode":false}}'),('empty-game-list','validate_gamelist','{}')]
s='#!/system/bin/sh\nset -eu\nM=/data/adb/modules/encore_pixel_cp41\nT=$(mktemp /data/local/tmp/encore-ui-schema.XXXXXX)\ntrap \'rm -f "$T"\' EXIT\n'
for name,command,value in cases:
    data=base64.b64encode(value.encode()).decode(); expected=0 if name=='empty-game-list' else 1
    s+=f"printf '%s' '{data}' | base64 -d > \"$T\"\nset +e\n\"$M/bin/encored\" {command} \"$T\"\nR=$?\nset -e\n[ \"$R\" = {expected} ] || exit 1\necho {name}_PASS\n"
(b/'validate-webui-schema.sh').write_text(s,newline='\n')
