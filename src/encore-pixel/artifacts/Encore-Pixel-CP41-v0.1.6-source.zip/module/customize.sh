#!/system/bin/sh
ui_print "Encore Pixel CP41 0.1.6 test (upstream 5.2.1)"
[ "$(getprop ro.product.device)" = mustang ] || abort "Only Pixel 10 Pro XL / mustang is supported"
[ "$(getprop ro.build.id)" = CP41.260831.007 ] || abort "This package is pinned to CP41.260831.007"
[ "$ARCH" = arm64 ] || abort "arm64 required"
C=/data/adb/.config/encore_pixel_cp41
mkdir -p "$C"
chmod 700 "$C"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
for s in service.sh action.sh uninstall.sh ui-state.sh ui-write.sh; do set_perm "$MODPATH/$s" 0 0 0755; done
(cd "$MODPATH" && sha256sum -c INSTALL_SHA256SUMS) || abort "Install payload checksum failed"
for f in config.json device_mitigation.json default_cpu_gov; do
 [ -f "$C/$f" ] || cp "$MODPATH/defaults/$f" "$C/$f"
done
[ -f "$C/gamelist.json" ] || "$MODPATH/bin/encored" setup_gamelist "$MODPATH/gamelist.txt" || abort "Game list setup failed"
"$MODPATH/bin/encored" check_gamelist || abort "Invalid game list"
"$MODPATH/bin/pixel-control" probe || abort "Pixel frequency interface check failed"
ui_print "Before reboot: disable Pixel Global Game Uclamp 0.3.2 and original Encore."
ui_print "Keep your separate thermal module if desired."
ui_print "Full/lite game modes; restores requests on exit, screen off or battery saver."
ui_print "Foreground game: disables Android default 60 FPS policy; restores on exit."
ui_print "WebUI: status, game list, Lite mode and high-frame-rate preferences."
ui_print "No per-frame feedback controller in this fork."
