#!/system/bin/sh
M=/data/adb/modules/encore_pixel_cp41
C=/data/adb/.config/encore_pixel_cp41
date
printf 'boot='; cat /proc/sys/kernel/random/boot_id
printf 'uptime='; cat /proc/uptime
printf 'battery='; cat /sys/class/power_supply/battery/capacity
printf 'temp='; cat /sys/class/power_supply/battery/temp
printf 'hal='; pidof android.hardware.power-service.pixel-libperfmgr
printf 'version='; grep '^version=' "$M/module.prop"
printf 'checksum_errors='; (cd "$M" && sha256sum -c SHA256SUMS) | grep -v ': OK$' | wc -l
sh "$M/ui-state.sh"
echo RECENT_CONTROL_ERRORS
tail -n 150 "$C/controller.log" | grep -E 'FAILED|failure|ERROR|YIELD|stopping|DENY|blocked' || true
echo RECENT_SERVICE_ERRORS
tail -n 150 "$C/service.log" | grep -E 'FAILED|failure|ERROR|YIELD|stopping|controller_exit' || true
echo RECENT_NATIVE_ERRORS
tail -n 150 "$C/encore.log" | grep -E ' E | F |Failed|fatal' || true
