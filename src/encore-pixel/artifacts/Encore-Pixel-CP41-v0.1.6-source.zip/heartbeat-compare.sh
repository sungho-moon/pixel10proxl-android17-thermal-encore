#!/system/bin/sh
C=/data/adb/.config/encore_pixel_cp41
for i in 1 2; do
 echo SAMPLE=$i
 date
 cat /proc/uptime
 printf 'heartbeat='; cat "$C/heartbeat" 2>/dev/null
 printf 'scene='; cat "$C/scene" 2>/dev/null
 printf 'status='; cat "$C/status" 2>/dev/null
 printf 'controller_sched='; cat /proc/9846/schedstat 2>/dev/null
 printf 'brain_sched='; cat /proc/9853/schedstat 2>/dev/null
 [ "$i" = 1 ] && sleep 4
done
